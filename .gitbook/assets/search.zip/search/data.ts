export interface Song {
  id: number;
  name: string;
  album: string;
  duration: number;
  artist: string;
  genre: string;
  image: string;
}

const songs: Song[] = require('./songs.json');

export { songs };
