import express from "express";
import { Song, songs } from "./data";
import moment from "moment";

const app = express();

app.set("view engine", "ejs");

app.set("port", 3000);

app.use(express.urlencoded({extended: false}));
app.use(express.json());

interface Stats {
    totalDuration: number;
    averageDuration: number;
    genres: string[];
}

const filter = (songs: Song[], searchString: string) => {
    return songs.filter((song) => {
        if (song.name.toLowerCase().includes(searchString.toLocaleLowerCase()) || song.artist.toLowerCase().includes(searchString.toLocaleLowerCase()) || song.album.toLowerCase().includes(searchString) || song.genre.toLowerCase().includes(searchString.toLocaleLowerCase())) {
            return true;
        }
    });
}

const getStats = (songs: Song[]): Stats => {
    let totalDuration = songs.reduce((acc, song) => {
        return acc + song.duration;
    },0);

    let averageDuration = totalDuration / songs.length;

    let genres = songs.map((song) => song.genre).filter((genre, index, arr) => {
        return arr.indexOf(genre) === index;
    });

    return {
        totalDuration: totalDuration,
        averageDuration: averageDuration,
        genres: genres
    }
}


app.get("/", (req,res) => {
    let searchString = req.query.q as string || "";
    let sortDirection = req.query.sortDirection as string || "asc";
    let sortField = req.query.sortField as string || "name";
    let filteredSongs = filter(songs, searchString);
    
    filteredSongs = filteredSongs.sort((a: any,b : any) => {
        if (sortDirection === "asc") {
            if (a[sortField] < b[sortField]) {
                return -1;
            } else if (a[sortField] > b[sortField]) {
                return 1;
            } else {
                return 0;
            }
        } else {
            if (a[sortField] < b[sortField]) {
                return 1;
            } else if (a[sortField] > b[sortField]) {
                return -1;
            } else {
                return 0;
            }
        }
    });


    res.render("index", {
        songs: filteredSongs,searchString:searchString, sortDirection:sortDirection, sortField: sortField, stats: getStats(filteredSongs)});
});


app.listen(app.get("port"), () => {
    app.locals.formatSeconds = (seconds: number) => {
        const formatted = moment.utc(seconds*1000).format('HH:mm:ss');
        return formatted;
    };
    console.log(`App started on port ${app.get("port")}`);
});
