# Oefening: Search Song

## Opgave

Deze applicatie gebruikt dezelfde dataset als de `Muziekanalyse` oefening.

Bij deze applicatie begin je met een bestaande express applicatie. Zorg eerst goed dat je de applicatie begrijpt. De applicatie bestaat uit een zoekveld en een lijst van songs. De songs worden opgehaald uit een json bestand. De applicatie is nog niet volledig functioneel. De bedoeling is dat je de applicatie verder afwerkt.

De GET route `/` aanvaard drie query parameters:
- `q`: de zoekstring. Als deze parameter niet aanwezig is, dan worden alle songs getoond. Als de parameter wel aanwezig is, dan worden enkel de songs getoond waarvan de naam, artiest, album of genre de zoekstring bevat.
- `sortDirection`: de sorteerrichting. Als deze parameter niet aanwezig is, dan worden de songs gesorteerd op naam in oplopende richting. Als de parameter wel aanwezig is, dan worden de songs gesorteerd op het veld dat gespecifieerd is in de `sortField` parameter. De sorteerrichting wordt bepaald door deze parameter. De mogelijke waarden zijn `asc` en `desc`.
- `sortField`: het veld waarop gesorteerd wordt. Als deze parameter niet aanwezig is, dan worden de songs gesorteerd op naam. Als de parameter wel aanwezig is, dan worden de songs gesorteerd op het veld dat gespecifieerd is in deze parameter. De mogelijke waarden zijn `name` en `duration`.

Je mag in deze opgave geen gebruik maken van for loops. Je moet dus gebruik maken van de array methodes `filter`, `indexOf`, `map`, `reduce` en `sort`. 

Bij het opstarten van de express applicatie zal je het volgende zien:

Uiteindelijk zal de applicatie er als volgt uitzien:

### Start situatie

import express from "express";
import { songs } from "./data";

const app = express();

app.set("view engine", "ejs");

app.set("port", 3000);

app.use(express.urlencoded({ extended: false }));
app.use(express.json());

app.get("/", (req, res) => {
  res.render("index", {
    songs: songs,
    searchString: "",
    sortDirection: "asc",
    sortField: "name",
    stats: {
      totalDuration: 0,
      averageDuration: 0,
      genres: ["rock", "pop"],
    },
  });
});

app.listen(app.get("port"), () => {
  app.locals.formatSeconds = (seconds: number) => {
    return seconds;
  };
  console.log(`App started on port ${app.get("port")}`);
});


### Voorbeeldoplossing

import express from "express";
import { Song, songs } from "./data";
import moment from "moment";

const app = express();

app.set("view engine", "ejs");

app.set("port", 3000);

app.use(express.urlencoded({extended: false}));
app.use(express.json());

interface Stats {
    totalDuration: number;
    averageDuration: number;
    genres: string[];
}

const filter = (songs: Song[], searchString: string) => {
    return songs.filter((song) => {
        if (song.name.toLowerCase().includes(searchString.toLocaleLowerCase()) || song.artist.toLowerCase().includes(searchString.toLocaleLowerCase()) || song.album.toLowerCase().includes(searchString) || song.genre.toLowerCase().includes(searchString.toLocaleLowerCase())) {
            return true;
        }
    });
}

const getStats = (songs: Song[]): Stats => {
    let totalDuration = songs.reduce((acc, song) => {
        return acc + song.duration;
    },0);

    let averageDuration = totalDuration / songs.length;

    let genres = songs.map((song) => song.genre).filter((genre, index, arr) => {
        return arr.indexOf(genre) === index;
    });

    return {
        totalDuration: totalDuration,
        averageDuration: averageDuration,
        genres: genres
    }
}


app.get("/", (req,res) => {
    let searchString = req.query.q as string || "";
    let sortDirection = req.query.sortDirection as string || "asc";
    let sortField = req.query.sortField as string || "name";
    let filteredSongs = filter(songs, searchString);
    
    filteredSongs = filteredSongs.sort((a: any,b : any) => {
        if (sortDirection === "asc") {
            if (a[sortField] < b[sortField]) {
                return -1;
            } else if (a[sortField] > b[sortField]) {
                return 1;
            } else {
                return 0;
            }
        } else {
            if (a[sortField] < b[sortField]) {
                return 1;
            } else if (a[sortField] > b[sortField]) {
                return -1;
            } else {
                return 0;
            }
        }
    });


    res.render("index", {
        songs: filteredSongs,searchString:searchString, sortDirection:sortDirection, sortField: sortField, stats: getStats(filteredSongs)});
});


app.listen(app.get("port"), () => {
    app.locals.formatSeconds = (seconds: number) => {
        const formatted = moment.utc(seconds*1000).format('HH:mm:ss');
        return formatted;
    };
    console.log(`App started on port ${app.get("port")}`);
});
