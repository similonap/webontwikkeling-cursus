import { Song, songs } from "./data";

console.log("Short songs (duration <= 200):");
let shortSongs = songs.filter((song) => song.duration <= 200);
console.table(shortSongs);

console.log("Unique genres:");
let genres = songs.map((song) => song.genre).filter((genre, index, arr) => { 
  return arr.indexOf(genre) === index;
});
console.table(genres);

console.log("Unique albums:");
let albums = songs.map((song) => song.album).filter((album, index, arr) => {
  return arr.indexOf(album) === index;
});
console.table(albums);

console.log("Unique artists:");
let artists = songs.map((song) => song.artist).filter((artist, index, arr) => {
  return arr.indexOf(artist) === index;
});
console.table(artists);

console.log("Total duration of all songs:");
let totalDuration = songs.reduce((acc, song) => {
  return acc + song.duration;
},0);
console.log(totalDuration);

console.log("Songs grouped by genre:");
interface SongByGenre {
  genre: string;
  songs: string[];
}
let songsByGenre: SongByGenre[] = genres.map((genre) => {
  return {
    genre: genre,
    songs: songs.filter((song) => song.genre === genre).map((song) => song.name)
  }
});
console.table(songsByGenre);

console.log("Songs grouped by genre (using reduce):");
let songsByGenreReduced : SongByGenre[] = songs.reduce((acc: SongByGenre[], song: Song) => {
  let sbg = acc.find(s => s.genre === song.genre);
  if (sbg) {
    sbg.songs.push(song.name)
  } else {
    acc.push({
      genre: song.genre,
      songs: [song.name]
    })
  }
  return acc;
}, []);
console.table(songsByGenreReduced);

console.log("Number of songs per artist:");
interface SongsPerArtist {
  [key: string]: number
}
let songsPerArtist: SongsPerArtist = songs.reduce((acc: SongsPerArtist, curr: Song) => {
  if (acc[curr.artist]) {
    acc[curr.artist]++;
  } else {
    acc[curr.artist] = 1;
  }
  return acc;
}, {});
console.table(songsPerArtist);

console.log("Average song length:");
let averageSongLength = songs.reduce((prev, curr) => {
  return prev + curr.duration;
}, 0) / songs.length;
console.log(Math.round(averageSongLength));

console.log("Songs sorted by length (shortest to longest):");
let sortedSongsByLength = [...songs].sort((a, b) => a.duration - b.duration);
console.table(sortedSongsByLength);

console.log("Artists sorted by song count (descending):");
let sortedArtistsBySongCount = [...artists].sort((a,b) => {
  return songsPerArtist[b] - songsPerArtist[a];
});
console.table(sortedArtistsBySongCount);
