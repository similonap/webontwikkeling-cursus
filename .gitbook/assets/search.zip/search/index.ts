import express from "express";
import { songs } from "./data";

const app = express();

app.set("view engine", "ejs");

app.set("port", 3000);

app.use(express.urlencoded({ extended: false }));
app.use(express.json());

app.get("/", (req, res) => {
  res.render("index", {
    songs: songs,
    searchString: "",
    sortDirection: "asc",
    sortField: "name",
    stats: {
      totalDuration: 0,
      averageDuration: 0,
      genres: ["rock", "pop"],
    },
  });
});

app.listen(app.get("port"), () => {
  app.locals.formatSeconds = (seconds: number) => {
    return seconds;
  };
  console.log(`App started on port ${app.get("port")}`);
});
